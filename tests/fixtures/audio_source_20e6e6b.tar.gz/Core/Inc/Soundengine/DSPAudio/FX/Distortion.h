/*
 * Distortion.h
 *
 *  Created on: 26.08.2020
 *      Author: julian
 *
 * Copyright (C) 2012-2026 Erica Synths
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * This file is part of the LXR firmware. It is licensed under the GNU General
 * Public License version 3, with the additional permission and terms in
 * NOTICE.md. See LICENSE and NOTICE.md in the root of the repository.
 */

#include "Soundengine/AudioSample.h"

#ifndef SRC_SOUNDENGINE_DSPAUDIO_FX_DISTORTION_H_
#define SRC_SOUNDENGINE_DSPAUDIO_FX_DISTORTION_H_

#include "Soundengine/globals.h"
#include "Soundengine/config.h"


enum DistortionTypesEnum
{
	DISTORTION_TUBE,
	DISTORTION_FOLD,
	DISTORTION_RAT,
};

typedef struct DistortionStruct
{

	uint8_t distortionType;
	float drive;	//drive
	float p1;		//parameter 1
	float p2;		//parameter 2
	float p3;		//parameter 3

	//some filter states used in rat
	AudioReal hp1_state[2];
	AudioReal hp2_state[2];
	AudioReal hp3_state[2];
	AudioReal lp1_state[2];
	AudioReal lp2_state[2];
	AudioReal lp3_state[2];
	AudioReal slewState[2];

	AudioReal lastOut[2];


} MasterDistortion;



void Distortion_init(MasterDistortion *dist);
void Distortion_process(MasterDistortion *dist, AudioSample*fxBuffer, AudioSample* outL, AudioSample* outR, uint16_t size,  uint8_t channels, float dryWet);
void Distortion_setDrive(MasterDistortion *dist, float d);
void Distortion_setParam1(MasterDistortion *dist, float p);
void Distortion_setParam2(MasterDistortion *dist, float p);
void Distortion_setParam3(MasterDistortion *dist, float p);

#endif /* SRC_SOUNDENGINE_DSPAUDIO_FX_DISTORTION_H_ */
