/*
 * Soundengine.c
 *
 *  Created on: Mar 24, 2020
 *      Author: julian
 *
 * Copyright (C) 2012-2026 Erica Synths
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * This file is part of the LXR firmware. It is licensed under the GNU General
 * Public License version 3, with the additional permission and terms in
 * NOTICE.md. See LICENSE and NOTICE.md in the root of the repository.
 */

#include "Soundengine/AudioSample.h"
#include "Soundengine/AudioOutput24.h"
#include "Soundengine/DSPAudio/MainDjFilter.h"
#include "Soundengine/Soundengine.h"
#include "Soundengine/AudioCodecManager.h"
#include "Preset/PresetManager.h"
#include <string.h>
#include "Soundengine/USB/usb_manager.h"
#include "Soundengine/MIDI/Uart.h"

uint8_t soundengine_calcNextSampleBlock()
{
	// Snapshot the request atomically; DMA callbacks may preempt the renderer.
	uint32_t mask = __get_PRIMASK();
	__disable_irq();
	const uint8_t half = bCurrentSampleValid;
	const uint32_t generation = codec_requestGeneration;
	__set_PRIMASK(mask);
	if(half != SAMPLE_VALID)
	{
        /* Static scratch avoids audio-stack growth; renderer ownership is unchanged. */
        static INDTCMZ AudioSample render1[OUTPUT_DMA_SIZE*2];
        static INDTCMZ AudioSample render2[OUTPUT_DMA_SIZE*2];
        mixer_calcNextSampleBlock(render1, render2);
        for(unsigned i=0;i<OUTPUT_DMA_SIZE*2;++i)
            audio_output24_store(&dma_buffer[half*AUDIO_DMA_HALF_OFFSET+2*i], render1[i]);
        MainDjFilter_process24(render2, &dma_buffer2[half*AUDIO_DMA_HALF_OFFSET], OUTPUT_DMA_SIZE);
		mask = __get_PRIMASK();
		__disable_irq();
		// Do not erase a newer request if rendering missed a deadline.
		if(codec_requestGeneration == generation)
			bCurrentSampleValid = SAMPLE_VALID;
		__set_PRIMASK(mask);
		return 1;
	}

	return 0;
}

void soundengine_init()
{
	mixer_init();



	// start the audio codec
//#ifndef DEBUG
	CodecInit(SYNTH_FS);
//#endif

	parameterArray_init();

	euklid_init();

	int i;
	for(i=0;i<6;i++)
	{
		modNode_init(&velocityModulators[i]);
	}

	//init the seq speed
	seq_init();
	seq_setBpm(120);

	memset(midi_MidiChannels,0,8);
//	memset(midi_NoteOverride,0,7);

	initDrumVoice();
	Snare_init();
	HiHat_init();
	Cymbal_init();

	//precalc the first dma buffer block
	soundengine_calcNextSampleBlock();

	FPU->FPDSCR |= FPU_FPDSCR_FZ_Msk ; //enable flush to zero
}

void soundengine_process()
{
	codec_serviceDmaRecovery();
#if CALC_SAMPLES_IN_INTERRUPT
	__HAL_TIM_DISABLE_IT(&htim2, TIM_IT_UPDATE);
	//HAL_TIM_Base_Stop_IT(&htim2);
	seq_tick();
	soundengine_calcNextSampleBlock();
	__HAL_TIM_SetCounter(&htim2, 1950);
	//HAL_TIM_Base_Start_IT(&htim2);
	__HAL_TIM_ENABLE_IT(&htim2, TIM_IT_UPDATE);
#endif
	//generate next sample if no valid sample is present
#if !CALC_SAMPLES_IN_INTERRUPT
#if 1//#ifndef DEBUG
		seq_tick();
		soundengine_calcNextSampleBlock();



#endif
#endif
		//process midi on midi port
		uart_processMidi();

		//process the sequencer
	//	seq_tick(); //moved to tim 14?
	usb_tick();
	//process incoming frontpanel data
		//	uart_processFront();






	preset_morph_tick();
	//preset_morph_tick();
	//preset_morph_tick();

}

uint8_t soundengine_backgroundAudioBegin()
{
#if USE_INTERRUPT_ONLY_DURING_SAVE_PROJ
	//fails if it is already running (then whoever started it stops it)
	return HAL_TIM_Base_Start_IT(&htim2) == HAL_OK;
#else
	return 0;
#endif
}
//------------------------------------------------------------------
void soundengine_backgroundAudioEnd(uint8_t started)
{
#if USE_INTERRUPT_ONLY_DURING_SAVE_PROJ
	if(started)
		HAL_TIM_Base_Stop_IT(&htim2);
#endif
}
